
const container = document.getElementById("modContainer");

fetch("https://repo.bonemods.net/mods.json")
  .then(res => res.json())
  .then(data => {
    container.innerHTML = '';
    data.forEach(mod => {
      const card = document.createElement("div");
      card.className = "mod-card";
      card.innerHTML = `
        <h3>${mod.name}</h3>
        <p>${mod.description}</p>
        <p><strong>Patch:</strong> ${mod.patch ?? "Unknown"}</p>
      `;
      container.appendChild(card);
    });
  })
  .catch(err => {
    console.error("Failed to load mods:", err);
    container.innerHTML = "<p style='color:red;'>Could not load mods. Check back later.</p>";
  });
