<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

$host = "db5017759932.hosting-data.io";
$db = "dbu3614081";
$user = "dbu3614081";
$pass = "Q1q2q3q4999!!!@@@";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  http_response_code(500);
  echo json_encode(["error" => "DB connection failed"]);
  exit;
}

$mod_id = $_GET['mod_id'] ?? '';
if (!$mod_id) {
  http_response_code(400);
  echo json_encode(["error" => "Missing mod_id"]);
  exit;
}


$mod_id_safe = $conn->real_escape_string($mod_id);
$sql = "SELECT * FROM comments WHERE mod_id='$mod_id_safe' ORDER BY created_at DESC";
$result = $conn->query($sql);

$comments = [];
while ($row = $result->fetch_assoc()) {
  $comments[] = $row;
}

header("Content-Type: application/json");
echo json_encode($comments);

$conn->close();
?>
