<?php
$mysqli = new mysqli("db5017759932.hosting-data.io", "dbu3614081", "Q1q2q3q4999!!!@@@", "dbu3614081");
if ($mysqli->connect_error) {
  die("❌ Connection failed: " . $mysqli->connect_error);
}
echo "✅ MySQL connected!";
?>
