<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = "db5017759932.hosting-data.io";
$db = "dbu3614081";
$user = "dbu3614081";
$pass = "Q1q2q3q4999!!!@@@";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  http_response_code(500);
  die("Connection failed: " . $conn->connect_error);
}

$mod_id = $_POST['mod_id'] ?? '';
$username = $_POST['username'] ?? 'Anonymous';
$message = $_POST['message'] ?? '';

if (!$mod_id || !$message) {
  http_response_code(400);
  echo "Missing required fields.";
  exit;
}

$stmt = $conn->prepare("INSERT INTO comments (mod_id, username, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $mod_id, $username, $message);
$stmt->execute();

echo "Comment added!";
$stmt->close();
$conn->close();
?>
