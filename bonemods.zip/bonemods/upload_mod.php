<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$uploadDir = __DIR__;
$modFileDir = $uploadDir . "/mods/";
$thumbDir = $uploadDir . "/thumbnails/";
$jsonFile = __DIR__ . "/repo/mods.json";


// Ensure mods.json is writable
if (!file_exists($jsonFile)) {
  file_put_contents($jsonFile, "[]");
}
chmod($jsonFile, 0666);

// Ensure folders exist
if (!file_exists($modFileDir)) mkdir($modFileDir, 0755, true);
if (!file_exists($thumbDir)) mkdir($thumbDir, 0755, true);

// Grab form data
$id = $_POST['id'] ?? '';
$name = $_POST['name'] ?? '';
$desc = $_POST['description'] ?? '';
$patch = $_POST['patch'] ?? '';
$sdkver = $_POST['sdk_version'] ?? '';
$tags = $_POST['tags'] ?? '';
$type = $_POST['type'] ?? 'code';

if (!$id || !$name || !$desc || !isset($_FILES['modfile']) || !isset($_FILES['thumbnail'])) {
  http_response_code(400);
  die("Missing required fields or files.");
}

// Load existing mods.json
$mods = [];
if (file_exists($jsonFile)) {
  $mods = json_decode(file_get_contents($jsonFile), true);
  if (!is_array($mods)) $mods = [];
  foreach ($mods as $mod) {
    if ($mod['id'] === $id) {
      http_response_code(409);
      die("A mod with this ID already exists.");
    }
  }
}

// Save mod ZIP
$modZip = $_FILES['modfile'];
$modFilename = basename($modZip['name']);
$modPath = $modFileDir . $modFilename;

if (!move_uploaded_file($modZip['tmp_name'], $modPath)) {
  http_response_code(500);
  die("Failed to save mod ZIP file.");
}

// Compress and save thumbnail
$thumb = $_FILES['thumbnail'];
$thumbPath = $thumbDir . $id . ".jpg";

$srcImage = imagecreatefromstring(file_get_contents($thumb['tmp_name']));
if ($srcImage === false) {
  http_response_code(500);
  die("Failed to process thumbnail image.");
}
imagejpeg($srcImage, $thumbPath, 75);
imagedestroy($srcImage);

// Build mod entry
$imageURL = "https://bonemods.net/thumbnails/" . $id . ".jpg";
$modEntry = [
  "id" => $id,
  "name" => $name,
  "description" => $desc,
  "patch" => $patch,
  "type" => $type,
  "image" => $imageURL,
  "filename" => $modFilename,
  "sdk_version" => $sdkver,
  "tags" => $tags
];

// Append and save
$mods[] = $modEntry;
if (file_put_contents($jsonFile, json_encode($mods, JSON_PRETTY_PRINT)) === false) {
  http_response_code(500);
  die("Failed to update mods.json");
}

echo "✅ Mod uploaded and added to mods.json!";
?>
